open Proposition
open Formule

(* Adapteurs de code *)

(** Création d'une formule équivalente à la formule UnSeul xs, depuis une liste de formule xs.  *)
let unSeul (_ : formule list) : formule = failwith "à faire"

(** Création d'une formule équivalente à la formule Tous xs, depuis une liste de formule xs.  *)
let tous = fun lf ->
	match 
	fold_list

(**(_ : formule list) : formule = failwith "à faire"*)
