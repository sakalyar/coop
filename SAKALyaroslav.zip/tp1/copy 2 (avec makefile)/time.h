#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifndef __HEURE_H
#define __HEURE_H

void affiche_heure_gmt(void);
void affiche_heure_locale(void);
char *ascheure(const struct tm *tmptr);

#endif
