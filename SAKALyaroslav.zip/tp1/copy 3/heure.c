// ???
#include "time.h"

void affiche_heure_gmt(void) {
	time_t t;
	struct tm *h;
	
	if ((t = time(NULL)) == NULL) {
		perror("time");
		exit(EXIT_FAILURE);		
	}
	// f ~ gmtime;
	h = gmtime(&t);
	if ( h == NULL) {
		perror("gmtime");
		exit(EXIT_FAILURE);
	}
	printf("Il est : %i heure %i min %i sec\n", h->tm_hour, h->tm_min, h->tm_sec);
	exit(EXIT_SUCCESS);
	
	exit(EXIT_FAILURE);
}

void affiche_heure_locale(void) {
	time_t t;
	t = time(NULL);
	
	if (t == (time_t) - 1) {
		perror("time");
	}
	struct tm *h;
	h = localtime(&t);
	if (h == NULL) {
		perror("localtime");
		exit(EXIT_FAILURE);
	}
	printf("Il est : %i heure %i min %i sec\n", h->tm_hour, h->tm_min, h->tm_sec);
	exit(EXIT_SUCCESS);
	
	exit(EXIT_FAILURE);
}

char *ascheure(const struct tm *tmptr) {
	char *value = malloc(100);
	const char * months[12] = { 
        " Janvier ", " Février ", " Mars ", " Avril ", " Mai ", " Juin ", " Juillet ",
        " Août ", " Septembre ", " Octobre ", " Novembre ", " Décembre "
    };
	const char *weeks[7] = {"Lundi ", "Mardi ", "Mercredi ", "Jeudi ", 
							"Vendredi ", "Samedi ", "Dimanche "};
	char day[32];
	sprintf(day, "%d", tmptr->tm_mday);
	printf("%s\n\n", day);
	for (int i = 0; i < 100; i++)
		value[i] = '\0';
	int dweek = tmptr->tm_wday;
	// Copying Week day
	int len = strlen("Aujourd\'hui c\'est ");
	strcpy(value, "Aujourd\'hui c\'est ");
	strcpy(value+len, weeks[dweek-1]);
	len += strlen(weeks[dweek-1]);
	// Copying a month day
	strcpy(value+len, day);
	len+=strlen(day);
	strcpy(value+len, months[tmptr->tm_mon]);
	int len2 = strlen(weeks[dweek-1])+strlen("1");
	len += len2;
	
	//printf("%s", months[tmptr->tm_mon]);
	
	
	//strcpy(value+len, weeks[0]);
	//value = ("Aujourd\'hui c\'est ");
	//int len = strlen("Aujourd\'hui c\'est ");
	//len += (strlen(tmptr->tm_wday) + 1);
	//strcpy(value + len, itoa(tmptr->tm_mon));
	//len += strlen(tmptr->tm_mon) + 1;
	//strcpy(value + len, tmptr->tm_year);
	//value = &("Aujourd\'hui c\'est %s %i %s %i\nIl est %i:%i:%i",
			//tmptr->tm_wday, tmptr->tm_yday, tmptr->tm_mon, tmptr->tm_year,
		//    tmptr->tm_hour, tmptr->tm_min, tmptr->tm_sec);
	//return value;
	//strcpy(value, tmptr->tm_wday);
	//char *day;
	//strcpy(value, "Aujourd\'hui c\'est %s %i %s %i\nIl est %i:%i:%i",
		   //tmptr->tm_wday, tmptr->tm_yday, tmptr->tm_mon, tmptr->tm_year,
		//   tmptr->tm_hour, tmptr->tm_min, tmptr->tm_sec);
	return value;
	//printf("Il est : %i heure %i min %i sec\n", tmptr->tm_hour, tmptr->tm_min, tmptr->tm_sec);
	//return NULL;
}

