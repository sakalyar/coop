#ifndef _TYPE_SYNTH
#define _TYPE_SYNTH

typedef enum type_synth {
	NUM,
	TYPE_ERR,
	VARIABLE_INDEFINI
} type_synth;

#endif
