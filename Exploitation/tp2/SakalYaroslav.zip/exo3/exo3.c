#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	int option;
	
	if (argc > 1 && argv[1] == 'l')
	while ((option = getopt(argc, argv, "lgs")) != -1) {
		case 'l':
		
		  break;
		default:
			break;
	}
	
	
}
