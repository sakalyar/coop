#include <stdio.h>
#include <stdlib.h>

int main() {
	int i = 0;
	int cnt = 0;
	int x;
	int t;
	scanf("%d", &x);
	//~ while(t = fork() && cnt++ < x)  {
		
	//~ }
	while(x-- && i++) {
		switch(fork()) {
			case -1:
				perror("fork");
				exit(EXIT_FAILURE);
			case 0:
				printf("Je suis un processus: %d\n", i);
				exit(EXIT_SUCCESS);
			default:
				wait();
				printf("Tous les %d processus sont terminés\n", x);
				exit(EXIT_SUCCESS);
		}
	}
}
